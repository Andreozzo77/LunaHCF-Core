<?php



/**

 * Created by PhpStorm.

 * User: FRISCOWZ

 * Date: 11/18/2017

 * Time: 12:53 AM

 */





namespace friscowz\hc\commands;





use friscowz\hc\MDPlayer;

use friscowz\hc\Myriad;

use friscowz\hc\utils\Utils;

use pocketmine\command\CommandSender;

use pocketmine\command\ConsoleCommandSender;

use pocketmine\command\PluginCommand;

use pocketmine\utils\TextFormat;





class RankCommand extends PluginCommand{



    public $whitelisted = ["chaqsxp", "gdrgamingzz"];



    /**

     * RankCommand constructor.

     *

     * @param Myriad $plugin

     */



    public function __construct(Myriad $plugin){



        parent::__construct("rank", $plugin);



    }





    public function execute(CommandSender $sender, string $commandLabel, array $args){



        if($sender->isOp()){



            $sender->sendMessage(TextFormat::GREEN . "

§eHCLounge Rank Statistics and Values

§7Default: 
§binfo:
§7Default Rank Has Access to Default Permissions and is the Rank you join with
§cPerms- skits.choose factions.core essentials.core capes.core
Access: §a§lOnly a  §cAdministrator can edit this Rank.
Rank Value:/setrank [playername] §c0
§aPrice: 0$
Tier: 0
§5§l----------------------------------------------------------------------------

§6Bronze: 
§binfo:
§7Bronze Rank Has Access to Default Permissions and Other Exclusive Perms You can Purchase This Rank
on our Buycraft Bronze Rank is a Tier 1 Rank
§cPerms- skits.choose factions.core essentials.core capes.core kits.bronze capes.choose
Access: §a§lOnly a  §cAdministrator can edit this Rank.
Rank Value:/setrank [playername] §c2
§aPrice: 3$
§3Tier: 1
§5§l-------------------------------------------------------------------------

§rSilver 
§binfo:
§rSilver Rank Has Access to Default Permissions and Other Exclusive Perms You can Purchase This Rank
on our Buycraft Bronze Rank is a Tier 1 Rank
§cPerms- skits.choose factions.core essentials.core capes.core kits.bronze capes.choose
Access: §a§lOnly a  §cAdministrator can edit this Rank.
Rank Value:/setrank [playername] §c3
§aPrice: 3$
§3Tier: 1
§5§l-------------------------------------------------------------------------

§eGold 3
§eDiamond: 4
§6TrialMod: 6
§6Mod: 7
§6Admin: 8
§6Head Admin: 9
§6Owner: 10
§dFamous: 12
§dPartner: 13

            

              

             ");



            if(count($args) == 2){



                if($args[1] < MDPlayer::HEAD_ADMIN){



                    $player = $sender->getServer()->getPlayer($args[0]);



                    if($player){



                        if($player instanceof MDPlayer){



                            $player->setRank($args[1]);



                            $player->sendMessage(Utils::getPrefix() . TextFormat::GREEN . "§aYour rank was changed by an §l§aAdmin");



                            $sender->sendMessage(Utils::getPrefix() . TextFormat::GREEN . "You have successfully updated " . $player->getName() . "'s rank!");



                        }



                    }



                }else{



                    if(in_array(strtolower($sender->getName()), $this->whitelisted) or $sender instanceof ConsoleCommandSender){



                        $player = $sender->getServer()->getPlayer($args[0]);



                        if($player){



                            if($player instanceof MDPlayer){



                                $player->setRank($args[1]);



                                $player->sendMessage(Utils::getPrefix() . TextFormat::GREEN . "Y§aYour rank was changed by an §l§aAdmin");



                                $sender->sendMessage(Utils::getPrefix() . TextFormat::GREEN . "You have successfully updated " . $player->getName() . "'s rank!");



                            }



                        }



                    }



                }



            }



        }



    }



}