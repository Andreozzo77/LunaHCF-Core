<?php

/**

 * Created by PhpStorm.

 * User: FRISCOWZ

 * Date: 05/11/2017

 * Time: 23:13

 */



namespace friscowz\hc\commands;





use friscowz\hc\FactionsManager;

use friscowz\hc\Myriad;

use pocketmine\command\CommandSender;

use pocketmine\command\PluginCommand;



class ClaimCommand extends PluginCommand{

    private $plugin;

    private $players = [];



    /**

     * ClaimCommand constructor.

     *

     * @param Myriad $plugin

     */

    public function __construct(Myriad $plugin){

        parent::__construct("claim", $plugin);

        $this->setPlugin($plugin);

    }



    /**

     * @param Myriad $plugin

     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }



    public function execute(CommandSender $sender, string $commandLabel, array $args){

        if($sender->isOp()){

            if(!isset($this->players[$sender->getName()])){

                $this->players[$sender->getName()] = [

                    "pos1" => null,

                    "pos2" => null

                ];

            }

            if(isset($args[0])){

                switch($args[0]){

                    case "delete":

                        Myriad::getFactionsManager()->getDb()->exec("DELETE FROM claims WHERE faction = '$args[1]';");
                       $sender->sendMessage("§cClaim Removed");

                        break;



                    case "pos1":

                        $this->players[$sender->getName()]["pos1"] = $sender->getPosition();

                        $sender->sendMessage("§l§aClaim Position 1 Sucsesfully Set");
                        $sender->sendMessage("§l§dClaim Another Position To Continue");

                        break;



                    case "pos2":

                        $this->players[$sender->getName()]["pos2"] = $sender->getPosition();

                        $sender->sendMessage("§l§aClaim Position 2 Sucsesfully Set");
                        $sender->sendMessage("§l§dNow You Can Do§r§e/claim confirm <spawn:protected> ");

                        break;



                    case "confirm":

                        if(isset($args[1])){

                            if($args[1] == "spawn"){

                                Myriad::getFactionsManager()->claim($args[1], $this->players[$sender->getName()]["pos1"], $this->players[$sender->getName()]["pos2"], FactionsManager::SPAWN);

                                $sender->sendMessage("§l§6Spawn Reigon Claim Set");

                            }else{

                                Myriad::getFactionsManager()->claim($args[1], $this->players[$sender->getName()]["pos1"], $this->players[$sender->getName()]["pos2"], FactionsManager::PROTECTED);

                                $sender->sendMessage("§l§6Protected Reigon Claim Set");

                            }

                        }

                        break;

                }

            }

        }

    }



    /**

     * @return Myriad

     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

}