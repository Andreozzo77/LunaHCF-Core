<?php


declare(strict_types=1);


namespace friscowz\logger;


use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as TF;


class Core extends PluginBase{


    /** @var JoinMessage $joinmessage */

    private $joinmessage;

    /** @var JoinTitle $jointitle */

    private $jointitle;


    public function onEnable() : void{

        $this->getServer()->getLogger()->info(TF::LIGHT_PURPLE . "[Vehz (Core)]" . TF::GREEN . " 

     ------------Loaded----------

     -------HCFactions--------
     -------SOTW--------
     -------EOTW--------
     -------Skits--------
     -------Koths--------
     ---------------------------------
     All Koth Areas Have Been Prepared!
     ---------------------------------
     -------CombatTag--------
     -------Knockback--------");

        $this->getServer()->getPluginManager()->registerEvents(($this->kb = new KB()), $this);


    }

}

