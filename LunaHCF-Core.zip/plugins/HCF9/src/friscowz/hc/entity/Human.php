<?php

declare(strict_types=1);

namespace friscowz\hc\entity;

class Human extends \pocketmine\entity\Human{

}