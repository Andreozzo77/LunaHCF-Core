<?php

/**
 * Created by VCS.
 * User: NotzideVCS
 * Date: 07/23/2019
 * Time: 21:27
 */


namespace friscowz\hc\commands;


use friscowz\hc\Myriad;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;


class QuickLinks extends PluginCommand{

    private $plugin;

    /**
     * FactionCommand constructor.
     *
     * @param Myriad $plugin
     */

    public function __construct(Myriad $plugin){

        parent::__construct("links", $plugin);

        $this->setPlugin($plugin);

        $this->setAliases(["quicklinks"]);

    }

    /**
     * @param Myriad $plugin
     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }

    /**
     * @return Myriad
     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

    /**
     * @param CommandSender $sender
     * @param string        $commandLabel
     * @param array         $args
     *
     * @return bool|mixed|void
     */

    public function execute(CommandSender $sender, string $commandLabel, array $args){

        $sender->sendMessage("§l§aHCLounge§r §7| §fKitmap");
        $sender->sendMessage("§7============================");
        $sender->sendMessage("§cLinks§r§7:");
        $sender->sendMessage("§bTwitter - COMING SOON");
        $sender->sendMessage("§9Discord - mfYBENe");
        $sender->sendMessage("§2IP - kitmap.hclounge.net");
        $sender->sendMessage("§7============================");


        return;

    }

}