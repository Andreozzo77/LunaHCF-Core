<?php

/**

 * Created by PhpStorm.

 * User: FRISCOWZ

 * Date: 13/08/2017

 * Time: 21:27

 */



namespace friscowz\hc\commands;



use friscowz\hc\Myriad;

use pocketmine\command\CommandSender;

use pocketmine\command\PluginCommand;



class DropCommand extends PluginCommand{

    private $plugin;



    /**

     * FactionCommand constructor.

     *

     * @param Myriad $plugin

     */

    public function __construct(Myriad $plugin){

        parent::__construct("dropset", $plugin);

        $this->setPlugin($plugin);

        $this->setAliases(["d", "drop", "illdrop"]);

    }



    /**

     * @param Myriad $plugin

     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }



    /**

     * @param CommandSender $sender

     * @param string        $commandLabel

     * @param array         $args

     *

     * @return bool|mixed|void

     */

    public function execute(CommandSender $sender, string $commandLabel, array $args){

        $this->getMyriad()->getServer()->broadcastMessage("§8---------------------------------------------");

        $this->getMyriad()->getServer()->broadcastMessage("§l§e" . $sender->getName() . " §l§aI will drop my set!");

        $this->getMyriad()->getServer()->broadcastMessage("§8---------------------------------------------");



        return;

    }



    /**

     * @return Myriad

     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

}