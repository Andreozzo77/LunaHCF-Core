<?php

/**
 * Created by PhpStorm.
 * User: CHAQSPHPSTORM
 * Date: 03/05/2019
 * Time: 21:27
 */


namespace friscowz\hc\commands;


use friscowz\hc\Myriad;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;


class SkitlistCommand extends PluginCommand{

    public $plugin;

    /**
     * FactionCommand constructor.
     *
     * @param Myriad $plugin
     */

    public function __construct(Myriad $plugin){

        parent::__construct("skitlist", $plugin);

        $this->setPlugin($plugin);

        $this->setAliases(["skitlist", "rankedkits", "myskits" ,"classes"]);

    }

    /**
     * @param Myriad $plugin
     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }

    /**
     * @return Myriad
     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

    /**
     * @param CommandSender $sender
     * @param string        $commandLabel
     * @param array         $args
     *
     * @return bool|mixed|void
     */

    public function execute(CommandSender $sender, string $commandLabel, array $args){

        $sender->sendMessage("§l§5HCLounge§r §f| §7Skits");
        $sender->sendMessage("§7============================");
        $sender->sendMessage("§ePurchase them at our BuyCraft Kink");
        $sender->sendMessage("§dHCLounge: §d24 hour cooldown");


        return;

    }

}