<?php

/**
 * Created by PhpStorm.
 * User: CHAQSPHPSTORM
 * Date: 03/05/2019
 * Time: 21:27
 */


namespace friscowz\hc\commands;


use friscowz\hc\Myriad;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;


class InfoCommand extends PluginCommand{

    private $plugin;

    /**
     * FactionCommand constructor.
     *
     * @param Myriad $plugin
     */

    public function __construct(Myriad $plugin){

        parent::__construct("info", $plugin);

        $this->setPlugin($plugin);

        $this->setAliases(["info", "serverinfo", "twitter"]);

    }

    /**
     * @param Myriad $plugin
     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }

    /**
     * @return Myriad
     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

    /**
     * @param CommandSender $sender
     * @param string        $commandLabel
     * @param array         $args
     *
     * @return bool|mixed|void
     */

    public function execute(CommandSender $sender, string $commandLabel, array $args){

        $sender->sendMessage("§l§aHCLounge§r §7| §fKitmap");
        $sender->sendMessage("§7============================");
        $sender->sendMessage("§cInformation§r§7:");
        $sender->sendMessage("§bTwitter - COMING SOON");
        $sender->sendMessage("NOTZIDE NOTZIDE NOTZIDE NOTZIDE NOTZIDE NOTZIDE MADE THIS");
        $sender->sendMessage("§4STAFF IS CLOSED NOTZIDE IS BEST :D");
        $sender->sendMessage("§7============================");


        return;

    }

}