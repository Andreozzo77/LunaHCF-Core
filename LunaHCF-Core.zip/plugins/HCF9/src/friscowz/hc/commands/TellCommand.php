<?php





namespace friscowz\hc\commands;



use pocketmine\command\CommandSender;



use pocketmine\event\TranslationContainer;



use pocketmine\Player;



use pocketmine\command\PluginCommand;



use friscowz\hc\Myriad;



use friscowz\hc\MDPlayer;









use pocketmine\utils\TextFormat;



class TellCommand extends PluginCommand



{



    private $plugin;



    /**



     * FactionCommand constructor.



     * @param Myriad $plugin



     */



    public function __construct (Myriad $plugin)



    {



        parent::__construct("tell", $plugin);









	}



	public function execute(CommandSender $sender, $currentAlias, array $args){



		if(!$this->testPermission($sender)){



			return true;



		}



		if(count($args) < 2){







			return false;



		}



		$name = strtolower(array_shift($args));



		$player = $sender->getServer()->getPlayer($name);



		if($player === $sender){



			$sender->sendMessage(new TranslationContainer(TextFormat::RED . "%commands.message.sameTarget"));



			return true;



		}



		if($player instanceof MDPlayer){



			$sender->sendMessage("§l§8(§r§eHCLounge§l§8)§r §dMe§5 -> §d" . $player->getDisplayName() . " §f" . implode(" ", $args));



                        $player->sendMessage("§l§8(§r§eHCLounge§l§8)§r§d " . ($sender instanceof Player ? $sender->getDisplayName() : $sender->getName()) . " §5->§d Me§f " . implode(" ", $args));



		}else{



			$sender->sendMessage(new TranslationContainer("commands.generic.player.notFound"));



		}



		return true;



	}



}



