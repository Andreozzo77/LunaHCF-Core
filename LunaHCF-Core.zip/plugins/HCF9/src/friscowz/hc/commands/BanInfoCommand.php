<?php

/**
 * Created by PhpStorm.
 * User: CHAQSPHPSTORM
 * Date: 03/05/2019
 * Time: 21:27
 */


namespace friscowz\hc\commands;

use pocketmine\Player;
use friscowz\hc\Myriad;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\math\Vector3;
use pocketmine\event\Listener;



class BanInfoCommand extends PluginCommand{

    private $plugin;

    /**
     * FactionCommand constructor.
     *
     * @param Myriad $plugin
     */

    public function __construct(Myriad $plugin){

        parent::__construct("info", $plugin);

        $this->setPlugin($plugin);

        $this->setAliases(["baninfo", "staffinfo", "binfo", "staffhelp"]);

    }

    /**
     * @param Myriad $plugin
     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }

    /**
     * @return Myriad
     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

    /**
     * @param CommandSender $sender
     * @param string        $commandLabel
     * @param array         $args
     *
     * @return bool|mixed|void
     */

    public function execute(CommandSender $sender, string $commandLabel, array $args){
        //$level = $player->getLevel();
        //$level->addSound(new GhastShootSound($player->asVector3()));\
        $player->getlevel()->addSound(new EndermanTeleportSound($player));
        $sender->sendMessage("§l§aHCLounge§r §7| §eBanInfo");
        $sender->sendMessage("§7============================");
        $sender->sendMessage("§cXray: 5 hours");
        $sender->sendMessage("§bAutoclicker:§c 2 day ban ");
        $sender->sendMessage("§eToxcity: Mute");
        $sender->sendMessage("§eDDOS Threats: Perm Ban");
        $sender->sendMessage("§7============================");


        return;

    }

}