<?php

/**

 * Created by PhpStorm.

 * User: FRISCOWZ

 * Date: 15/08/2017

 * Time: 02:45

 */



namespace friscowz\hc\commands;




use friscowz\hc\Myriad;

use friscowz\hc\utils\Utils;

use pocketmine\command\CommandSender;

use pocketmine\command\PluginCommand;

use pocketmine\utils\TextFormat;



class ClownCommand extends PluginCommand{

    private $plugin;



    /**

     * SOTWCommand constructor.

     *

     * @param Myriad $plugin

     */

    public function __construct(Myriad $plugin){

        parent::__construct("clown", $plugin);

        $this->setPlugin($plugin);

    }



    /**

     * @param Myriad $plugin

     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }



    /**

     * @param CommandSender $sender

     * @param string        $commandLabel

     * @param array         $args

     *

     * @return bool|mixed|void

     */

    public function execute(CommandSender $sender, string $commandLabel, array $args){

        if($sender->isOp()){

            if(isset($args[0])){

                if(strtolower($args[0]) == "list"){

                    $sender->sendMessage(TextFormat::RED . "Â§rÂ§cList Of Retarded Clowns!");
                    $sender->sendMessage(TextFormat::RED . "Â§7---------------------------");
                    $sender->sendMessage(TextFormat::RED . "Â§eNotzide");
                    $sender->sendMessage(TextFormat::RED . "Â§exJqsh");
                    $sender->sendMessage(TextFormat::RED . "Â§eDatPigMaster");
                    $sender->sendMessage(TextFormat::RED . "Â§7---------------------------");







                }elseif(strtolower($args[0]) == "offfffffffff"){

                    $sender->sendMessage(TextFormat::RED . "Stopped SOTW Protection.");


                }else $sender->sendMessage(TextFormat::RED . "Usage: /clown <list>");

            }else $sender->sendMessage(TextFormat::RED . "Usage: /clown <list>");

        }else $sender->sendMessage(Utils::getPrefix() . TextFormat::RED . "You don't have the permission to run this command!");

    }



    /**

     * @return Myriad

     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

}