<?php



/**

 * Created by PhpStorm.

 * User: FRISCOWZ

 * Date: 12/08/2017

 * Time: 20:23

 */





namespace friscowz\hc\listener;





use friscowz\{hc\FactionsManager, hc\MDPlayer, hc\Myriad, hc\utils\Utils};


use pocketmine\event\Listener;

use pocketmine\event\player\PlayerItemConsumeEvent;
use friscowz\hc\listener\PlayerCreationEvent;
    

use pocketmine\event\server\DataPacketReceiveEvent;

use pocketmine\item\{Item, ItemIds};

use pocketmine\math\Vector3;


use pocketmine\network\mcpe\protocol\LoginPacket;

use pocketmine\utils\TextFormat;





class SnowballListener implements Listener{



    private $plugin;



    






public static $snowball = [];




    

    /**

     * PlayerListener constructor.

     *

     * @param Myriad $plugin

     */



    public function __construct(Myriad $plugin){



        $this->setPlugin($plugin);



        $this->getPlugin()->getServer()->getPluginManager()->registerEvents($this, $this->getPlugin());



    }





    /**

     * @return mixed

     */



    public function getPlugin() : Myriad{



        return $this->plugin;



    }





    /**

     * @param mixed $plugin

     */



    public function setPlugin($plugin){



        $this->plugin = $plugin;



    }





    /**

     * @param PlayerCreationEvent $event

     */



    public function onCreation(PlayerCreationEvent $event){



        $event->setPlayerClass(MDPlayer::class);



    }





    /**

     * @param PlayerMoveEvent $event

     */



    

public function onConsume(PlayerItemConsumeEvent $event){

$player = $event->getPlayer();



        $item = $event->getItem();



        



        /*



        if(Myriad::getManager()->isPCBlock($block)){



            Myriad::getManager()->convertBlock($block);



        }*/



        //$player->sendMessage($block->getId() . " : " . $block->getDamage());



        
        //$player->sendMessage($block->getId() . " : " . $block->getDamage());



        if($item->getId() == ItemIds::SNOWBALL){



            if($player->getLevel()->getBlockIdAt($player->x, $player->y + 1, $player->z) != 0){



                



                return;



            }



            $event->setCancelled(false);

                if(!isset(self::$snowball[$player->getName()])){



                    self::$snowball[$player->getName()] = time();



                }else{



                    if((time() - self::$snowball[$player->getName()]) < 16){



                        $timer = time() - self::$snowball[$player->getName()];



                        $player->sendMessage(TextFormat::YELLOW . "§5Snowball Item Is Currently on Cooldown wait 15s!");

$event->setCancelled(true);

                        return;



                    }else{



                        self::$snowball[$player->getName()] = time();



if($player->isSurvival()){



                    $item->setCount($item->getCount() - 1);



                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item : Item::get(Item::AIR));




                }

                    

}
}
}


   

    }





}