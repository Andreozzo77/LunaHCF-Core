<?php

declare(strict_types=1);

namespace friscowz\hc\commands;


use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;


public
function execute(CommandSender $sender, string $commandLabel, array $args){
    parent::__construct("itemrename", "Rename an item.", "/itemrename <new name>", ["irename", "irn"]);
    $this->setPermission("itemrename.rename");
    $this->loader = $loader;
}

public
function execute(CommandSender $sender, string $commandLabel, array $args) : bool{
    if(!$this->testPermission($sender)){
        return false;
    }
    if(!$sender instanceof Player){
        $sender->sendMessage(TF::RED . "Please run this command in-game.");

        return true;
    }
    if(empty($args)){
        $sender->sendMessage(TF::RED . $this->getUsage());

        return true;
    }
    $item = $sender->getInventory()->getItemInHand();
    if($item === null){
        $sender->sendMessage(TF::RED . "You are not holding an item!");

        return true;
    }
    $item->clearCustomName();
    $item->setCustomName(str_replace("&", TF::ESCAPE, $args[0]));
    $sender->setItemInHand($item);
    if($this->getPlugin()->getConfig()->get("Display-Message", true)){
        $sender->sendMessage("§l§8(§5Arcadium§8)§r§a You Have Sucsesfully Renamed Your Item!");
    }

    return true;
}

public
function getPlugin() : Loader{
    return $this->loader;
}
}