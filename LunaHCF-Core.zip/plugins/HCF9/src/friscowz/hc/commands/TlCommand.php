<?php

/**

 * Created by PhpStorm.

 * User: FRISCOWZ

 * Date: 13/08/2017

 * Time: 21:27

 */



namespace friscowz\hc\commands;



use friscowz\hc\Myriad;

use friscowz\hc\MDPlayer;

use friscowz\hc\utils\Utils;

use pocketmine\command\CommandSender;

use pocketmine\command\PluginCommand;

use pocketmine\utils\TextFormat;
use pocketmine\level\Position;
use pocketmine\level\Level;



class TlCommand extends PluginCommand

{

    private $plugin;

    /**

     * FactionCommand constructor.

     * @param Myriad $plugin

     */

    public function __construct (Myriad $plugin)

    {

        parent::__construct("tl", $plugin);

        $this->setPlugin($plugin);

        $this->setAliases(["telllocation", "location", "locationtell"]);

    }



    /**

     * @return Myriad

     */

    public function getMyriad () : Myriad

    {

        return $this->plugin;

    }



    /**

     * @param Myriad $plugin

     */

    public function setPlugin (Myriad $plugin)

    {

        $this->plugin = $plugin;

    }

    

    /**

     * @param CommandSender $sender

     * @param string $commandLabel

     * @param array $args

     * @return bool|mixed|void

     */

    public function execute (CommandSender $sender, string $commandLabel, array $args)

    {
 
   $tl = $sender->getLevel()->getName();
   $x = $sender->getFloorX();
   $y = $sender->getFloorY();
   $z = $sender->getFloorz();
  


     $sender->setChat(MDPlayer::FACTION);
     $sender->chat(" §e(§a X: " . $x . " Y: " . $y . " Z: " . $z . "§e) §eCome Help§f.");


    return;

    }

}