<?php

/**
 * Created by PhpStorm.
 * User: CHAQSPHPSTORM
 * Date: 03/05/2019
 * Time: 21:27
 */


namespace friscowz\hc\commands;


use friscowz\hc\Myriad;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;


class MapCommand extends PluginCommand{

    private $plugin;

    /**
     * FactionCommand constructor.
     *
     * @param Myriad $plugin
     */

    public function __construct(Myriad $plugin){

        parent::__construct("mapinfo", $plugin);

        $this->setPlugin($plugin);

        $this->setAliases(["maxenchants", "map", "enchants"]);

    }

    /**
     * @param Myriad $plugin
     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }

    /**
     * @return Myriad
     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

    /**
     * @param CommandSender $sender
     * @param string        $commandLabel
     * @param array         $args
     *
     * @return bool|mixed|void
     */

    public function execute(CommandSender $sender, string $commandLabel, array $args){

        $sender->sendMessage("§l§5Arcadium§r §f| §7Map 4");
        $sender->sendMessage("§7============================");
        $sender->sendMessage("§l§dMap Enchants§r§7:");
        $sender->sendMessage("§bSharpness§7:§f 1");
        $sender->sendMessage("§bProtection§7:§f 2");
        $sender->sendMessage("§bUnbreaking§7:§f 3");
        $sender->sendMessage("§7============================");
        $sender->sendMessage("§l§cCoords§r§7:");
        $sender->sendMessage("§7(§l§2Overworld§r§7)");
        $sender->sendMessage("§7----------------------------");
        $sender->sendMessage("§aSpawn§f: §70,0");
        $sender->sendMessage("§fEnd Portal§f: §71000,1000");
        $sender->sendMessage("§6Glowstone Mountain§f: §73000,3000");


        return;

    }

}