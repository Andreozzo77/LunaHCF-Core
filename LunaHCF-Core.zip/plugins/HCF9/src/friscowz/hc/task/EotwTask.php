<?php

/**
 * Created by PhpStorm.
 * User: xVqle
 * Date: 13/08/2019
 * Time: 01:18
 */


namespace friscowz\hc\task;


use friscowz\hc\modules\EOTW;
use friscowz\hc\Myriad;
use pocketmine\scheduler\Task;


class EotwTask extends Task{


    private $plugin;

    private $time;


    /**
     * SotwTask constructor.
     *
     * @param Myriad $plugin
     */

    public function __construct(Myriad $plugin){

        $this->setPlugin($plugin);

        $this->setHandler($this->getPlugin()->getScheduler()->scheduleRepeatingTask($this, 20));

        $this->setTime(60 * 90);

    }

    /**
     * @return Myriad
     */

    public function getPlugin() : Myriad{

        return $this->plugin;

    }

    /**
     * @param Myriad $plugin
     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }

    /**
     * Actions to execute when run
     *
     * @param int $currentTick
     *
     * @return void
     */

    public function onRun(int $currentTick){

        $this->setTime($this->getTime() - 1);

        if($this->getTime() == 0){

            EOTW::stop();

        }

    }

    /**
     * @return mixed
     */

    public function getTime() : int{

        return $this->time;

    }


    /**
     * @param mixed $time
     */

    public function setTime(int $time){

        $this->time = $time;

    }


    /**
     *

     */

    public function cancel(){

        $this->getHandler()->cancel();

    }

}