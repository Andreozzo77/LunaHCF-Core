<?php


namespace friscowz\hc\entities;


use CortexPE\SynCORE\modules\base\BaseModule;
use CortexPE\SynHCF\entity\projectile\EnderPearl;
use pocketmine\entity\Entity;

class TalibanPearls extends BaseModule{
    public function initialize() : void{
        Entity::registerEntity(EnderPearl::class, false, ['ThrownEnderpearl', 'minecraft:ender_pearl']);
    }
}