<?php

/**

 * Created by PhpStorm.

 * User: FRISCOWZ

 * Date: 15/08/2017

 * Time: 02:45

 */



namespace friscowz\hc\commands;



use friscowz\hc\modules\SALE;

use friscowz\hc\Myriad;

use friscowz\hc\utils\Utils;

use pocketmine\command\CommandSender;

use pocketmine\command\PluginCommand;

use pocketmine\utils\TextFormat;



class SALECommand extends PluginCommand{

    private $plugin;



    /**

     * SALECommand constructor.

     *

     * @param Myriad $plugin

     */

    public function __construct(Myriad $plugin){

        parent::__construct("sale", $plugin);

        $this->setPlugin($plugin);

    }



    /**

     * @param Myriad $plugin

     */

    public function setPlugin(Myriad $plugin){

        $this->plugin = $plugin;

    }



    /**

     * @param CommandSender $sender

     * @param string        $commandLabel

     * @param array         $args

     *

     * @return bool|mixed|void

     */

    public function execute(CommandSender $sender, string $commandLabel, array $args){

        if($sender->isOp()){

            if(isset($args[0])){

                if(strtolower($args[0]) == "enable"){

                    $sender->sendMessage(TextFormat::YELLOW . "You Have Started The Sale for 25% Off!");

                    $sender->sendPopup(TextFormat::GREEN . "We have a sale going on our buycraft for 25% off");

                    $this->getMyriad()->getServer()->broadcastMessage("§aWe are now hosting our SALE on our Buycraft");



                    SALE::start();

                }elseif(strtolower($args[0]) == "disable"){

                    $sender->sendMessage(TextFormat::YELLOW . "You Have Stopped The 25% Off Sale!");

                    SALE::stop();

                }else $sender->sendMessage(Utils::getPrefix() . TextFormat::RED . "Usage: /sale <enable|disable>");

            }else $sender->sendMessage(Utils::getPrefix() . TextFormat::RED . "Usage: /sale <enable|disable>");

        }else $sender->sendMessage(Utils::getPrefix() . TextFormat::RED . "You don't have the permission to run this command!");

    }



    /**

     * @return Myriad

     */

    public function getMyriad() : Myriad{

        return $this->plugin;

    }

}