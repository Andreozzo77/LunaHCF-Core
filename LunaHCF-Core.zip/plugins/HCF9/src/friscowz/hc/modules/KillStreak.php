<?php
/**
 * Created by PhpStorm.
 * User: FRISCOWZ
 * Date: 11/27/2017
 * Time: 8:46 PM
 */

namespace friscowz\hc\modules;


use pocketmine\event\Listener;

class KillStreak implements Listener{

}